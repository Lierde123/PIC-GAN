import os
gpus = ','.join([str(i) for i in [0,1]])
os.environ["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID"
os.environ["CUDA_VISIBLE_DEVICES"] = gpus
import torch
torch.backends.cudnn.benchmark = True
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
import utils
from data_RGB import get_training_data, get_validation_data
from warmup_scheduler.scheduler import GradualWarmupScheduler
from tqdm import tqdm
from utils.pytorch_ssim import *

from net.G import Net


def torchPSNR(tar_img, prd_img):
    imdff = torch.clamp(prd_img,0,1) - torch.clamp(tar_img,0,1)
    rmse = (imdff**2).mean().sqrt()
    ps = 20*torch.log10(1/rmse)
    return ps

gpus = ','.join([str(i) for i in [0,1]])
os.environ["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID"
os.environ["CUDA_VISIBLE_DEVICES"] = gpus

torch.backends.cudnn.benchmark = True

def _train():
    #criterion_char = losses.CharbonnierLoss()
    model = Net()

    model.cuda()
    Num_Epoch = 200

    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    device_ids = [i for i in range(torch.cuda.device_count())]
    if torch.cuda.device_count() >= 1:
        print("\n\nLet's use", torch.cuda.device_count(), "GPUs!\n\n")

    if len(device_ids) > 1:
        model = nn.DataParallel(model, device_ids=device_ids)

    criterion = torch.nn.L1Loss()
    optimizer = torch.optim.AdamW(model.parameters(),lr=1e-4,weight_decay=0)

    ######### Scheduler ###########
    warmup_epochs = 3
    scheduler_cosine = optim.lr_scheduler.CosineAnnealingLR(optimizer, Num_Epoch - warmup_epochs,
                                                            eta_min=1e-7)
    scheduler = GradualWarmupScheduler(optimizer, multiplier=1, total_epoch=warmup_epochs,
                                       after_scheduler=scheduler_cosine)
    scheduler.step()

    train_dir = 'datauieb/train/'
    val_dir = 'datauieb/val/'

    train_dataset = get_training_data(train_dir, {'patch_size': 256})
    train_loader = DataLoader(dataset=train_dataset, batch_size=2, shuffle=True, num_workers=0,drop_last=False, pin_memory=True)

    val_dataset = get_validation_data(val_dir, {'patch_size': 256})
    val_loader = DataLoader(dataset=val_dataset, batch_size=1, shuffle=False, num_workers=0, drop_last=False,pin_memory=True)

    model_dir = os.path.join('checkpoints/UIENet')
    utils.mkdir(model_dir)

    best_psnr=-1
    best_epoch = 0
    epoch = 1

    for epoch_idx in range(epoch, Num_Epoch +1):
        print(epoch_idx)
        for iter_idx, data in enumerate(tqdm(train_loader), 0):
            label_img = data[0].cuda()
            input_img = data[1].cuda()

            input_img = input_img.to(device)
            label_img = label_img.to(device)

            optimizer.zero_grad()
            pred_img = model(input_img)

            loss = criterion(pred_img, label_img)

            loss.backward()
            optimizer.step()

        if epoch_idx % 1 == 0:
            model.eval()
            ssim_val_rgb = []
            psnr_val_rgb = []

            for ii, data_val in enumerate((val_loader), 0):
                target = data_val[0].cuda()
                input_ = data_val[1].cuda()
                with torch.no_grad():
                    rest = model(input_)

                restored = rest

                ssim_val_rgb.append(ssim(restored, target))
                for res, tar in zip(restored, target):
                    psnr_val_rgb.append(torchPSNR(res, tar))
            psnr_val_rgb = torch.stack(psnr_val_rgb).mean().item()
            ssim_val_rgb = torch.stack(ssim_val_rgb).mean().item()

            if psnr_val_rgb > best_psnr:
                best_psnr = psnr_val_rgb
                best_epoch = epoch_idx
                torch.save({'epoch': best_epoch,
                            'state_dict': model.state_dict(),
                            'optimizer': optimizer.state_dict()
                            }, os.path.join(model_dir, "model_best.pth"))

            print("[epoch %d PSNR: %.4f --- best_epoch %d Best_PSNR %.4f SSIM %.4f]" % (epoch_idx, psnr_val_rgb, best_epoch, best_psnr, ssim_val_rgb))

        scheduler.step()
        print("------------------------------------------------------------------")

        torch.save({'epoch': epoch_idx,
                    'state_dict': model.state_dict(),
                     'optimizer' : optimizer.state_dict()
                    }, os.path.join(model_dir,"model_latest.pth"))

_train()