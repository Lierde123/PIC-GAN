import warnings
warnings.filterwarnings('ignore')
from ultralytics import YOLO

if __name__ == '__main__':
    model = YOLO('runs/train/best.pt') # select your model.pt path
    model.predict(source='ultralytics/assets/OIP-C (3).jpg',
                  imgsz=640,
                  project='runs/detect',
                  name='exp',
                  save=True,
                  classes=0,
                )