import os
import time
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager
from bs4 import BeautifulSoup
import requests

def download_image(url, folder_path, image_name):
    try:
        response = requests.get(url, stream=True)
        if response.status_code == 200:
            image_path = os.path.join(folder_path, image_name)
            with open(image_path, 'wb') as file:
                for chunk in response.iter_content(1024):
                    file.write(chunk)
            print(f"Image saved: {image_path}")
        else:
            print(f"Failed to download image from {url}")
    except Exception as e:
        print(f"Error downloading {url}: {e}")

def crawl_images(search_query, num_images, folder_path):
    # 确保文件夹存在
    if not os.path.exists(folder_path):
        os.makedirs(folder_path)

    # 配置Selenium WebDriver
    chrome_options = Options()
    chrome_options.add_argument("--headless")  # 无头模式，不打开浏览器窗口
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--disable-dev-shm-usage")

    # 使用webdriver_manager自动下载和管理ChromeDriver
    driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=chrome_options)
    driver.get(f"https://www.google.com/search?q={search_query}&tbm=isch")

    # 滚动页面以加载更多图片
    for _ in range(5):
        driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
        time.sleep(2)

    # 获取页面源码并解析
    page_source = driver.page_source
    soup = BeautifulSoup(page_source, 'html.parser')

    # 找到所有图片标签
    img_tags = soup.find_all('img', {'class': 'rg_i Q4LuWd'}, limit=num_images)

    print(f"Found {len(img_tags)} images for query: {search_query}")

    # 提取图片URL
    img_urls = []
    for img in img_tags:
        try:
            img_url = img['src']
        except KeyError:
            img_url = img.get('data-src')
        if img_url:
            img_urls.append(img_url)

    print(f"Extracted {len(img_urls)} image URLs for query: {search_query}")

    driver.quit()

    for index, img_url in enumerate(img_urls):
        img_name = f"{search_query.replace(' ', '_')}_{index + 1}.jpg"
        download_image(img_url, folder_path, img_name)

if __name__ == "__main__":
    search_queries = ["海鲈鱼"]  # 替换为你要搜索的关键字列表
    num_images = 50  # 每个关键字爬取图片的数量
    folder_path = "D:/数据集/六种自创鱼类数据集/images/Lateolabrax_japonicas"  # 保存图片的文件夹

    for query in search_queries:
        crawl_images(query, num_images, folder_path)
