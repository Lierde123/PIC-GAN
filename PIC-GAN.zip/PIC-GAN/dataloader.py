import os
import cv2
from torch.utils.data import Dataset
from torchvision import transforms
from PIL import Image


class UnderwaterPairDataset(Dataset):
    def __init__(self, root_dir, transform=None, mode='train'):
        self.root_dir = root_dir
        self.transform = transform
        self.mode = mode
        self.image_pairs = self.load_image_pairs()

    def load_image_pairs(self):
        image_pairs = []
        input_dir = os.path.join(self.root_dir, self.mode, 'input')
        target_dir = os.path.join(self.root_dir, self.mode, 'target')

        # 检查输入和目标目录是否存在
        if not os.path.exists(input_dir) or not os.path.exists(target_dir):
            raise FileNotFoundError(f"Input or target directory not found: {input_dir}, {target_dir}")

        for input_image_name in os.listdir(input_dir):
            input_image_path = os.path.join(input_dir, input_image_name)
            target_image_name = input_image_name.replace('input', 'target')
            target_image_path = os.path.join(target_dir, target_image_name)

            if os.path.exists(target_image_path):
                image_pairs.append((input_image_path, target_image_path))

        return image_pairs

    def __len__(self):
        return len(self.image_pairs)

    def __getitem__(self, idx):
        lowlight_image_path, normal_image_path = self.image_pairs[idx]

        # 使用 OpenCV 读取图像并转换为 RGB 格式
        lowlight_image = cv2.imread(lowlight_image_path)
        lowlight_image = cv2.cvtColor(lowlight_image, cv2.COLOR_BGR2RGB)

        normal_image = cv2.imread(normal_image_path)
        normal_image = cv2.cvtColor(normal_image, cv2.COLOR_BGR2RGB)

        # 转换为 PIL 图像
        lowlight_image = Image.fromarray(lowlight_image)
        normal_image = Image.fromarray(normal_image)

        # 应用变换
        if self.transform:
            lowlight_image = self.transform(lowlight_image)
            normal_image = self.transform(normal_image)

        return lowlight_image, normal_image
