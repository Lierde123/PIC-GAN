import json
import os

# 类别到索引的映射
class_mapping = {
    "Pink_Fish": 0,
    "Red_Fish": 1,
    "Yellow_Fish": 2,
    "Black_Fish": 3,
    "Green_Fish": 4,
}

def convert_json_to_yolo(json_path, output_dir):
    # 读取JSON文件
    with open(json_path, 'r') as f:
        data = json.load(f)

    # 获取图像宽度和高度
    image_width = data['imageWidth']
    image_height = data['imageHeight']

    # 获取JSON文件名（不含扩展名）
    json_filename = os.path.splitext(os.path.basename(json_path))[0]

    # 创建输出TXT文件路径
    txt_path = os.path.join(output_dir, f"{json_filename}.txt")

    # 打开TXT文件进行写入
    with open(txt_path, 'w') as f:
        for shape in data['shapes']:
            label = shape['label']
            points = shape['points']

            # 获取矩形框的左上角和右下角坐标
            x1, y1 = points[0]
            x2, y2 = points[1]

            # 计算中心点坐标
            x_center = (x1 + x2) / 2.0
            y_center = (y1 + y2) / 2.0

            # 计算宽度和高度
            width = abs(x2 - x1)
            height = abs(y2 - y1)

            # 归一化
            x_center /= image_width
            y_center /= image_height
            width /= image_width
            height /= image_height

            # 写入TXT文件
            f.write(f"{class_mapping[label]} {x_center} {y_center} {width} {height}\n")

    print(f"转换完成：{json_path} -> {txt_path}")

def batch_convert_json_to_yolo(json_dir, output_dir):
    # 确保输出目录存在
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    # 遍历JSON目录中的所有文件
    for filename in os.listdir(json_dir):
        if filename.endswith(".json"):
            json_path = os.path.join(json_dir, filename)
            convert_json_to_yolo(json_path, output_dir)

# 设置JSON文件目录和输出目录
json_directory = "E:/BaiduNetdiskDownload/W-GAN/W-GAN/fishself/Label/"  # 替换为你的JSON文件目录
output_directory = "E:/BaiduNetdiskDownload/W-GAN/W-GAN/fishself/Label_txt/"  # 替换为你的输出目录

# 批量转换
batch_convert_json_to_yolo(json_directory, output_directory)



