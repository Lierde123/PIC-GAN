import matplotlib.pyplot as plt
import networkx as nx

# 创建有向图
G = nx.DiGraph()

# 添加节点和边
G.add_node("Input", pos=(0, 0))
G.add_node("Conv1 (3x3, s2)", pos=(1, 0))
G.add_node("Padding1", pos=(2, 0))
G.add_node("Conv2a (2x2, s1)", pos=(3, 0.5))
G.add_node("Padding2", pos=(4, 0.5))
G.add_node("Conv2b (2x2, s1)", pos=(5, 0.5))
G.add_node("MaxPool (2x2, s1)", pos=(3, -0.5))
G.add_node("Concat", pos=(6, 0))
G.add_node("Conv3 (3x3, s2)", pos=(7, 0))
G.add_node("Conv4 (1x1, s1)", pos=(8, 0))
G.add_node("Output", pos=(9, 0))

G.add_edges_from([
    ("Input", "Conv1 (3x3, s2)"),
    ("Conv1 (3x3, s2)", "Padding1"),
    ("Padding1", "Conv2a (2x2, s1)"),
    ("Conv2a (2x2, s1)", "Padding2"),
    ("Padding2", "Conv2b (2x2, s1)"),
    ("Conv1 (3x3, s2)", "MaxPool (2x2, s1)"),
    ("Conv2b (2x2, s1)", "Concat"),
    ("MaxPool (2x2, s1)", "Concat"),
    ("Concat", "Conv3 (3x3, s2)"),
    ("Conv3 (3x3, s2)", "Conv4 (1x1, s1)"),
    ("Conv4 (1x1, s1)", "Output")
])

# 获取节点位置
pos = nx.get_node_attributes(G, 'pos')

# 绘制图形
plt.figure(figsize=(12, 6))
nx.draw(G, pos, with_labels=True, node_size=3000, node_color='lightblue', font_size=10, font_weight='bold', arrowsize=20, connectionstyle='arc3, rad=0.1')

# 调整边的位置
ax = plt.gca()
for edge in G.edges(data=True):
    ax.annotate("",
                xy=pos[edge[1]], xycoords='data',
                xytext=pos[edge[0]], textcoords='data',
                arrowprops=dict(arrowstyle="->", color="0.5",
                                shrinkA=15, shrinkB=15,
                                patchA=None, patchB=None,
                                connectionstyle="arc3,rad=0.1",
                                ),
                )
plt.title("HGStem Module Propagation Structure")
plt.show()
