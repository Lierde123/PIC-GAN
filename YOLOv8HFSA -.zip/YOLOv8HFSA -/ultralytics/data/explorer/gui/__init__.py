# Ultralytics YOLO 🚀, AGPL-3.0 license
