import torch
import torch.nn as nn
import torchvision.models as models
import torch.nn.init as init
import torch.nn.functional as F


class SEBlock(nn.Module):
    def __init__(self, in_channels, reduction=16):
        super(SEBlock, self).__init__()
        self.fc = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(in_channels, in_channels // reduction, kernel_size=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(in_channels, in_channels, kernel_size=1),
            nn.Sigmoid()
        )

    def forward(self, x):
        se = self.fc(x)
        return x * se


class ResBlock(nn.Module):
    def __init__(self, in_channels):
        super(ResBlock, self).__init__()
        self.conv1 = nn.Conv2d(in_channels, in_channels, kernel_size=3, padding=1)
        self.bn1 = nn.BatchNorm2d(in_channels)
        self.relu = nn.ReLU(inplace=True)
        self.conv2 = nn.Conv2d(in_channels, in_channels, kernel_size=3, padding=1)
        self.bn2 = nn.BatchNorm2d(in_channels)

    def forward(self, x):
        residual = x
        out = self.relu(self.bn1(self.conv1(x)))
        out = self.bn2(self.conv2(out))
        out += residual
        return out


class DepthwiseSeparableConv(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size=3, padding=1):
        super(DepthwiseSeparableConv, self).__init__()
        self.depthwise = nn.Conv2d(in_channels, in_channels, kernel_size=kernel_size, padding=padding, groups=in_channels, bias=False)
        self.pointwise = nn.Conv2d(in_channels, out_channels, kernel_size=1, bias=False)
        self.bn = nn.BatchNorm2d(out_channels)
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        x = self.depthwise(x)
        x = self.pointwise(x)
        x = self.bn(x)
        x = self.relu(x)
        return x


class CBAM(nn.Module):
    def __init__(self, channels, reduction=16):
        super(CBAM, self).__init__()
        self.channel_attention = ChannelAttention(channels, reduction)
        self.spatial_attention = SpatialAttention()

    def forward(self, x):
        x = self.channel_attention(x) * x
        x = self.spatial_attention(x) * x
        return x


class ChannelAttention(nn.Module):
    def __init__(self, in_planes, ratio=16):
        super(ChannelAttention, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.max_pool = nn.AdaptiveMaxPool2d(1)

        self.fc1 = nn.Conv2d(in_planes, in_planes // ratio, 1, bias=False)
        self.relu1 = nn.ReLU()
        self.fc2 = nn.Conv2d(in_planes // ratio, in_planes, 1, bias=False)

        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        avg_out = self.fc2(self.relu1(self.fc1(self.avg_pool(x))))
        max_out = self.fc2(self.relu1(self.fc1(self.max_pool(x))))
        out = avg_out + max_out
        return self.sigmoid(out)


class SpatialAttention(nn.Module):
    def __init__(self, kernel_size=7):
        super(SpatialAttention, self).__init__()

        assert kernel_size in (3, 7), 'kernel size must be 3 or 7'
        padding = 3 if kernel_size == 7 else 1

        self.conv1 = nn.Conv2d(2, 1, kernel_size, padding=padding, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        avg_out = torch.mean(x, dim=1, keepdim=True)
        max_out, _ = torch.max(x, dim=1, keepdim=True)
        x = torch.cat([avg_out, max_out], dim=1)
        x = self.conv1(x)
        return self.sigmoid(x)


class MobileNetV2UNet(nn.Module):
    def __init__(self):
        super(MobileNetV2UNet, self).__init__()
        mobilenet_v2 = models.mobilenet_v2(weights=models.MobileNet_V2_Weights.IMAGENET1K_V1)
        self.encoder1 = nn.Sequential(*list(mobilenet_v2.features[:2]), )
        self.encoder2 = nn.Sequential(*list(mobilenet_v2.features[2:4]), )
        self.encoder3 = nn.Sequential(*list(mobilenet_v2.features[4:7]), )
        self.encoder4 = nn.Sequential(*list(mobilenet_v2.features[7:14]), )
        self.bottleneck = nn.Sequential(*list(mobilenet_v2.features[14:]),
                                        DepthwiseSeparableConv(1280, 1024, kernel_size=3, padding=1),
                                        CBAM(1024))

        self.upconv4 = nn.ConvTranspose2d(1024, 512, kernel_size=2, stride=2)
        self.decoder4 = self.decoder_block(512 + 96, 512)
        self.adjust_channels4 = DepthwiseSeparableConv(512, 512, kernel_size=1, padding=0)

        self.upconv3 = nn.ConvTranspose2d(512, 256, kernel_size=2, stride=2)
        self.decoder3 = self.decoder_block(256 + 32, 256)
        self.adjust_channels3 = DepthwiseSeparableConv(256, 256, kernel_size=1, padding=0)

        self.upconv2 = nn.ConvTranspose2d(256, 128, kernel_size=2, stride=2)
        self.decoder2 = self.decoder_block(128 + 24, 128)
        self.adjust_channels2 = DepthwiseSeparableConv(128, 128, kernel_size=1, padding=0)

        self.upconv1 = nn.ConvTranspose2d(128, 64, kernel_size=2, stride=2)
        self.decoder1 = self.decoder_block(64 + 16, 64)
        self.adjust_channels1 = DepthwiseSeparableConv(64, 64, kernel_size=1, padding=0)

        self.final_upsample = nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True)
        self.final_conv = nn.Conv2d(64, 3, kernel_size=1)

        self.apply(self._initialize_weights)
        self.dropout = nn.Dropout(0.3)

    def _initialize_weights(self, m):
        if isinstance(m, nn.Conv2d) or isinstance(m, nn.ConvTranspose2d) or isinstance(m, nn.Linear):
            init.kaiming_normal_(m.weight, mode='fan_in', nonlinearity='relu')

    def decoder_block(self, in_channels, out_channels):
        return nn.Sequential(
            DepthwiseSeparableConv(in_channels, out_channels, kernel_size=3, padding=1),
            DepthwiseSeparableConv(out_channels, out_channels, kernel_size=3, padding=1),
            CBAM(out_channels)
        )

    def forward(self, x):
        print(f"Input shape: {x.shape}")
        enc1 = self.encoder1(x)
        print(f"After encoder1: {enc1.shape}")
        enc2 = self.encoder2(enc1)
        print(f"After encoder2: {enc2.shape}")
        enc3 = self.encoder3(enc2)
        print(f"After encoder3: {enc3.shape}")
        enc4 = self.encoder4(enc3)
        print(f"After encoder4: {enc4.shape}")
        bottleneck = self.bottleneck(enc4)
        print(f"After bottleneck: {bottleneck.shape}")

        dec4 = self.upconv4(bottleneck)
        print(f"After upconv4: {dec4.shape}")
        dec4 = torch.cat((dec4, enc4), dim=1)
        print(f"After concat with enc4: {dec4.shape}")
        dec4 = self.decoder4(dec4)
        print(f"After decoder4: {dec4.shape}")
        dec4 = self.adjust_channels4(dec4)
        print(f"After adjust_channels4: {dec4.shape}")

        dec3 = self.upconv3(dec4)
        print(f"After upconv3: {dec3.shape}")
        dec3 = torch.cat((dec3, enc3), dim=1)
        print(f"After concat with enc3: {dec3.shape}")
        dec3 = self.decoder3(dec3)
        print(f"After decoder3: {dec3.shape}")
        dec3 = self.adjust_channels3(dec3)
        print(f"After adjust_channels3: {dec3.shape}")

        dec2 = self.upconv2(dec3)
        print(f"After upconv2: {dec2.shape}")
        dec2 = torch.cat((dec2, enc2), dim=1)
        print(f"After concat with enc2: {dec2.shape}")
        dec2 = self.decoder2(dec2)
        print(f"After decoder2: {dec2.shape}")
        dec2 = self.adjust_channels2(dec2)
        print(f"After adjust_channels2: {dec2.shape}")

        dec1 = self.upconv1(dec2)
        print(f"After upconv1: {dec1.shape}")
        dec1 = torch.cat((dec1, enc1), dim=1)
        print(f"After concat with enc1: {dec1.shape}")
        dec1 = self.decoder1(dec1)
        print(f"After decoder1: {dec1.shape}")
        dec1 = self.adjust_channels1(dec1)
        print(f"After adjust_channels1: {dec1.shape}")

        out = self.final_upsample(dec1)
        print(f"After final_upsample: {out.shape}")
        out = self.final_conv(out)
        print(f"After final_conv: {out.shape}")
        out = self.dropout(out)
        print(f"After dropout: {out.shape}")

        return out

if __name__ == "__main__":
    model = MobileNetV2UNet()
    dummy_input = torch.randn(8, 3, 256, 256)  # 假设输入是 batch size 为 8，3 个通道，256x256 的图像
    output = model(dummy_input)
