import torch
import torch.nn as nn
import torchvision.models as models
import torch.nn.init as init

class SEBlock(nn.Module):
    def __init__(self, in_channels, reduction=16):
        super(SEBlock, self).__init__()
        self.fc = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(in_channels, in_channels // reduction, kernel_size=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(in_channels, in_channels, kernel_size=1),
            nn.Sigmoid()
        )

    def forward(self, x):
        se = self.fc(x)
        return x * se

class ResBlock(nn.Module):
    def __init__(self, in_channels):
        super(ResBlock, self).__init__()
        self.conv1 = nn.Conv2d(in_channels, in_channels, kernel_size=3, padding=1)
        self.bn1 = nn.BatchNorm2d(in_channels)
        self.relu = nn.ReLU(inplace=True)
        self.conv2 = nn.Conv2d(in_channels, in_channels, kernel_size=3, padding=1)
        self.bn2 = nn.BatchNorm2d(in_channels)

    def forward(self, x):
        residual = x
        out = self.relu(self.bn1(self.conv1(x)))
        out = self.bn2(self.conv2(out))
        out += residual
        return out

class DepthwiseSeparableConv(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size=3, padding=1):
        super(DepthwiseSeparableConv, self).__init__()
        self.depthwise = nn.Conv2d(in_channels, in_channels, kernel_size=kernel_size, padding=padding, groups=in_channels, bias=False)
        self.pointwise = nn.Conv2d(in_channels, out_channels, kernel_size=1, bias=False)
        self.bn = nn.BatchNorm2d(out_channels)
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        x = self.depthwise(x)
        x = self.pointwise(x)
        x = self.bn(x)
        x = self.relu(x)
        return x

class CBAM(nn.Module):
    def __init__(self, channels, reduction=16):
        super(CBAM, self).__init__()
        self.channel_attention = ChannelAttention(channels, reduction)
        self.spatial_attention = SpatialAttention()

    def forward(self, x):
        x = self.channel_attention(x) * x
        x = self.spatial_attention(x) * x
        return x

class ChannelAttention(nn.Module):
    def __init__(self, in_planes, ratio=16):
        super(ChannelAttention, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.max_pool = nn.AdaptiveMaxPool2d(1)

        self.fc1 = nn.Conv2d(in_planes, in_planes // ratio, 1, bias=False)
        self.relu1 = nn.ReLU()
        self.fc2 = nn.Conv2d(in_planes // ratio, in_planes, 1, bias=False)

        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        avg_out = self.fc2(self.relu1(self.fc1(self.avg_pool(x))))
        max_out = self.fc2(self.relu1(self.fc1(self.max_pool(x))))
        out = avg_out + max_out
        return self.sigmoid(out)

class SpatialAttention(nn.Module):
    def __init__(self, kernel_size=7):
        super(SpatialAttention, self).__init__()

        assert kernel_size in (3, 7), 'kernel size must be 3 or 7'
        padding = 3 if kernel_size == 7 else 1

        self.conv1 = nn.Conv2d(2, 1, kernel_size, padding=padding, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        avg_out = torch.mean(x, dim=1, keepdim=True)
        max_out, _ = torch.max(x, dim=1, keepdim=True)
        x = torch.cat([avg_out, max_out], dim=1)
        x = self.conv1(x)
        return self.sigmoid(x)

class MobileNetV2UNet(nn.Module):
    def __init__(self):
        super(MobileNetV2UNet, self).__init__()
        mobilenet_v2 = models.mobilenet_v2(weights=models.MobileNet_V2_Weights.IMAGENET1K_V1)
        self.encoder1 = nn.Sequential(*list(mobilenet_v2.features[:2]), )
        self.encoder2 = nn.Sequential(*list(mobilenet_v2.features[2:4]), )
        self.encoder3 = nn.Sequential(*list(mobilenet_v2.features[4:7]), )
        self.encoder4 = nn.Sequential(*list(mobilenet_v2.features[7:14]), )
        self.bottleneck = nn.Sequential(*list(mobilenet_v2.features[14:]),
                                        DepthwiseSeparableConv(1280, 1024, kernel_size=3, padding=1),
                                        CBAM(1024))

        self.upconv4 = nn.ConvTranspose2d(1024, 512, kernel_size=2, stride=2)
        self.decoder4 = self.decoder_block(512 + 96, 512)
        # self.adjust_channels4 = DepthwiseSeparableConv(512, 512, kernel_size=1, padding=0)

        self.upconv3 = nn.ConvTranspose2d(512, 256, kernel_size=2, stride=2)
        self.decoder3 = self.decoder_block(256 + 32, 256)
        # self.adjust_channels3 = DepthwiseSeparableConv(256, 256, kernel_size=1, padding=0)

        self.upconv2 = nn.ConvTranspose2d(256, 128, kernel_size=2, stride=2)
        self.decoder2 = self.decoder_block(128 + 24, 128)
        # self.adjust_channels2 = DepthwiseSeparableConv(128, 128, kernel_size=1, padding=0)

        self.upconv1 = nn.ConvTranspose2d(128, 64, kernel_size=2, stride=2)
        self.decoder1 = self.decoder_block(64 + 16, 64)
        # self.adjust_channels1 = DepthwiseSeparableConv(64, 64, kernel_size=1, padding=0)

        self.final_upsample = nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True)
        self.final_conv = nn.Conv2d(64, 3, kernel_size=1)

        self.apply(self._initialize_weights)
        self.dropout = nn.Dropout(0.9)

    def _initialize_weights(self, m):
        if isinstance(m, nn.Conv2d) or isinstance(m, nn.ConvTranspose2d) or isinstance(m, nn.Linear):
            init.kaiming_normal_(m.weight, mode='fan_in', nonlinearity='relu')

    def decoder_block(self, in_channels, out_channels):
        return nn.Sequential(
            DepthwiseSeparableConv(in_channels, out_channels, kernel_size=3, padding=1),
            DepthwiseSeparableConv(out_channels, out_channels, kernel_size=3, padding=1),
            CBAM(out_channels)
        )

    def forward(self, x):
        enc1 = self.encoder1(x)
        enc2 = self.encoder2(enc1)
        enc3 = self.encoder3(enc2)
        enc4 = self.encoder4(enc3)
        bottleneck = self.bottleneck(enc4)

        dec4 = self.upconv4(bottleneck)
        # dec4 = F.interpolate(dec4, size=enc4.shape[2:], mode='bilinear', align_corners=True)
        dec4 = torch.cat((dec4, enc4), dim=1)
        dec4 = self.decoder4(dec4)
        # dec4 = self.adjust_channels4(dec4)

        dec3 = self.upconv3(dec4)
        # dec3 = F.interpolate(dec3, size=enc3.shape[2:], mode='bilinear', align_corners=True)
        dec3 = torch.cat((dec3, enc3), dim=1)
        dec3 = self.decoder3(dec3)
        # dec3 = self.adjust_channels3(dec3)

        dec2 = self.upconv2(dec3)
        # dec2 = F.interpolate(dec2, size=enc2.shape[2:], mode='bilinear', align_corners=True)
        dec2 = torch.cat((dec2, enc2), dim=1)
        dec2 = self.decoder2(dec2)
        # dec2 = self.adjust_channels2(dec2)

        dec1 = self.upconv1(dec2)
        # dec1 = F.interpolate(dec1, size=enc1.shape[2:], mode='bilinear', align_corners=True)
        dec1 = torch.cat((dec1, enc1), dim=1)
        dec1 = self.decoder1(dec1)
        # dec1 = self.adjust_channels1(dec1)

        out = self.final_upsample(dec1)
        out = self.final_conv(out)
        # out = self.dropout(out)

        return out


class PatchDiscriminator(nn.Module):
    def __init__(self, in_channels=3, ndf=64, num_layers=3):
        super(PatchDiscriminator, self).__init__()
        layers = [
            nn.Conv2d(in_channels, ndf, kernel_size=3, stride=2, padding=1),
            nn.LeakyReLU(0.2, inplace=False)  # 禁用原地操作
        ]

        nf_mult = 1
        nf_mult_prev = 1
        for n in range(1, num_layers):
            nf_mult_prev = nf_mult
            nf_mult = min(2 ** n, 8)
            layers += [
                nn.Conv2d(ndf * nf_mult_prev, ndf * nf_mult, kernel_size=3, stride=2, padding=1),
                nn.LeakyReLU(0.2, inplace=False)  # 禁用原地操作
            ]

        nf_mult_prev = nf_mult
        nf_mult = min(2 ** num_layers, 8)
        layers += [
            nn.Conv2d(ndf * nf_mult_prev, ndf * nf_mult, kernel_size=3, stride=1, padding=1),
            nn.LeakyReLU(0.2, inplace=False)  # 禁用原地操作
        ]

        layers += [nn.Conv2d(ndf * nf_mult, 1, kernel_size=3, stride=1, padding=1)]

        self.model = nn.Sequential(*layers)

        # 权重初始化
        self.apply(self._initialize_weights)

    def _initialize_weights(self, m):
        if isinstance(m, nn.Conv2d) or isinstance(m, nn.ConvTranspose2d) or isinstance(m, nn.Linear):
            init.kaiming_normal_(m.weight, mode='fan_in', nonlinearity='leaky_relu')  # 使用 Leaky ReLU

    def forward(self, x):
        return self.model(x)

class Discriminator(nn.Module):
    # discriminator model
    def __init__(self):
        super(Discriminator, self).__init__()

        self.t1 = nn.Sequential(
            nn.Conv2d(in_channels=3, out_channels=64, kernel_size=(4, 4), stride=2, padding=1),
            nn.LeakyReLU(0.2, inplace=True)
        )

        self.t2 = nn.Sequential(
            nn.Conv2d(in_channels=64, out_channels=128, kernel_size=(4, 4), stride=2, padding=1),
            nn.BatchNorm2d(128),
            nn.LeakyReLU(0.2, inplace=True)
        )

        self.t3 = nn.Sequential(
            nn.Conv2d(in_channels=128, out_channels=256, kernel_size=(7, 7), stride=2, padding=1),
            nn.BatchNorm2d(256),
            nn.LeakyReLU(0.2, inplace=True)
        )
        self.t4 = nn.Sequential(
            nn.Conv2d(in_channels=256, out_channels=512, kernel_size=(7, 7), stride=2, padding=1),
            nn.BatchNorm2d(512),
            nn.LeakyReLU(0.2, inplace=True)
        )
        self.t5 = nn.Sequential(
            nn.Conv2d(in_channels=512, out_channels=1, kernel_size=(13, 13), stride=1, padding=0),
            nn.Flatten(),
            nn.Sigmoid()
        )


    def forward(self, x):
        x = self.t1(x)
        x = self.t2(x)
        x = self.t3(x)
        x = self.t4(x)
        x = self.t5(x)
        y = x.shape[0]
        x = x.reshape(y,-1)
        return x  # output_6 of discriminator

