import matplotlib.pyplot as plt
import networkx as nx

def draw_partial_conv3_graph():
    G = nx.DiGraph()

    # Add nodes
    nodes = [
        "Input", "Split Channels", "Partial Conv3", "Concat Channels", "Output"
    ]
    G.add_nodes_from(nodes)

    # Add edges
    edges = [
        ("Input", "Split Channels"), ("Split Channels", "Partial Conv3"),
        ("Partial Conv3", "Concat Channels"), ("Split Channels", "Concat Channels"),
        ("Concat Channels", "Output")
    ]
    G.add_edges_from(edges)

    # Position nodes
    pos = nx.spring_layout(G, seed=42)

    # Draw the graph
    nx.draw(G, pos, with_labels=True, node_size=3000, node_color="skyblue", font_size=10, font_weight="bold", arrows=True)
    plt.title("Partial_conv3 Model Structure")
    plt.show()

# Generate the model structure graph for Partial_conv3
draw_partial_conv3_graph()
