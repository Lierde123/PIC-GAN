from ultralytics import YOLO
 # 加载训练好的模型
model = YOLO("yolov8n.pt")
# # 将模型转为onnx格式
success = model.export(format='onnx')