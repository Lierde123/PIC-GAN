from utils.pytorch_ssim import *
from fvcore.nn import FlopCountAnalysis
import torch.nn.functional as F
import torchvision.transforms as transforms
from skimage.metrics import peak_signal_noise_ratio as compare_psnr
from skimage.metrics import structural_similarity as compare_ssim
import lpips
from torch.utils.data import DataLoader, Dataset
from torchvision.transforms import Resize, ToTensor
import torch
from scipy.linalg import sqrtm
import torch.nn as nn
import numpy as np
from PIL import Image
import os
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"

# 计算模型参数数量
def count_parameters(model):
    return sum(p.numel() for p in model.parameters() if p.requires_grad)

# 计算模型FLOPs
def count_flops(model, input_size):
    dummy_input = torch.randn(1, *input_size)
    flops = FlopCountAnalysis(model, dummy_input)
    return flops.total()

# 换算成M和G
def convert_to_m_and_g(value):
    if value >= 1e9:
        return f"{value / 1e9:.2f}G"
    elif value >= 1e6:
        return f"{value / 1e6:.2f}M"
    else:
        return str(value)

# 定义数据集类
class ImagePairDataset(Dataset):
    def __init__(self, original_images, denoised_images):
        self.original_images = original_images
        self.denoised_images = denoised_images
        self.transform = transforms.Compose([
    transforms.Resize((256, 256)),
    transforms.ToTensor(),
])
    def __len__(self):
        return len(self.original_images)

    def __getitem__(self, idx):
        original_image = self.transform(self.original_images[idx])
        denoised_image = self.transform(self.denoised_images[idx])
        return original_image, denoised_image

# 定义PSNR计算函数
def calculate_psnr(original, denoised):
    return compare_psnr(original, denoised)

# 定义SSIM计算函数
def calculate_ssim(original, denoised):
    return compare_ssim(original, denoised, channel_axis=2,data_range=255)

# 定义LPIPS计算函数
def calculate_lpips(image1, image2, lpips_model):
    # 加载预训练的LPIPS模型
    # 使用LPIPS模型计算相似性
    similarity_score = lpips_model(image1, image2)

    return similarity_score.item()


if __name__ == "__main__":
    # 加载示例图像
    # model = UIEGAN()  #修改
    # input_size = (3, 256, 256)
    # # 计算参数数量
    # num_params = count_parameters(model)
    # # 计算FLOPs
    # num_flops = count_flops(model, input_size)

    original_images = []
    denoised_images = []

    dir_path = "LSUI/val/input/"  #修改
    original_dir = os.listdir("LSUI/val/target")

    denoised_dir = os.listdir(dir_path)

    lpips_model = lpips.LPIPS(net='alex')


    for i in range(len(denoised_dir)):
        name_denoised = denoised_dir[i]
        name_original = original_dir[i]

        original = Image.open("LSUI/val/target/" + name_original)
        denoised = Image.open(dir_path + name_denoised)

        original_images.append(original)
        denoised_images.append(denoised)

        #print("{}".format(i))

    dataset = ImagePairDataset(original_images, denoised_images)
    dataloader = DataLoader(dataset, batch_size=1, shuffle=False)

    psnr_values = []
    ssim_values = []
    lpips_values = []
    fid_values = []
    i = 0

    for original_tensor, denoised_tensor in dataloader:
        i = i + 1
        ssim_values.append(ssim(original_tensor, denoised_tensor))

        original_np = original_tensor.squeeze(0).permute(1, 2, 0).numpy()
        denoised_np = denoised_tensor.squeeze(0).permute(1, 2, 0).numpy()

        psnr_values.append(calculate_psnr(original_np, denoised_np))
        lpips_values.append(calculate_lpips(original_tensor, denoised_tensor, lpips_model))

        print("已完成{}张".format(i))


    print(f"PSNR: {np.mean(psnr_values)}")
    print(f"SSIM: {np.mean(ssim_values)}")
    print(f"LPIPS: {np.mean(lpips_values)}")