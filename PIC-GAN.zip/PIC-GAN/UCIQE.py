import cv2
import math
import numpy as np
import os

def calculate_uciqe(image):
    hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)  # 使用BGR到HSV的转换
    H, S, V = cv2.split(hsv)
    delta = np.std(H) / 180  # 色度的标准差
    mu = np.mean(S) / 255  # 饱和度的平均值
    n, m = np.shape(V)
    number = math.floor(n * m / 100)  # 所需像素的个数
    Maxsum, Minsum = 0, 0
    V1, V2 = V / 255, V / 255

    for _ in range(number):
        Maxvalue = np.amax(V1)
        x, y = np.where(V1 == Maxvalue)
        Maxsum += V1[x[0], y[0]]
        V1[x[0], y[0]] = 0

    top = Maxsum / number

    for _ in range(number):
        Minvalue = np.amin(V2)
        X, Y = np.where(V2 == Minvalue)
        Minsum += V2[X[0], Y[0]]
        V2[X[0], Y[0]] = 1

    bottom = Minsum / number

    conl = top - bottom
    uciqe = 0.4680 * delta + 0.2745 * conl + 0.2575 * mu
    return uciqe

def batch_calculate_uciqe(image_dir):
    uciqe_values = []

    # 遍历图像文件夹中的所有图像文件
    for filename in os.listdir(image_dir):
        image_path = os.path.join(image_dir, filename)
        image = cv2.imread(image_path)

        if image is None:
            print(f"无法读取图像: {image_path}")
            continue

        # 计算UCIQE
        uciqe = calculate_uciqe(image)
        uciqe_values.append(uciqe)
        print(f"图像 {filename} 的 UCIQE: {uciqe}")

    # 打印批量处理结果
    if uciqe_values:
        mean_uciqe = np.mean(uciqe_values)
        print(f"\n所有图像的 UCIQE 均值: {mean_uciqe}")

if __name__ == "__main__":
    image_dir = "samples2023/result/LSUI/enchance"  # 修改为你的图像文件夹路径
    batch_calculate_uciqe(image_dir)
