import os
import random
import shutil

def split_dataset(image_dir, label_dir, train_ratio=0.7):
    """
    将图片和对应的TXT标签文件按比例划分为训练集和验证集。

    参数:
        image_dir (str): 图片文件所在的目录。
        label_dir (str): 标签文件所在的目录。
        train_ratio (float): 训练集的比例，默认为0.7。
    """
    # 确保目录存在
    if not os.path.exists(image_dir) or not os.path.exists(label_dir):
        print("图片目录或标签目录不存在！")
        return

    # 获取图片和标签文件列表
    image_files = [f for f in os.listdir(image_dir) if f.endswith(('.jpg', '.png', '.jpeg', '.JPG'))]
    label_files = [f for f in os.listdir(label_dir) if f.endswith('.txt')]

    # 确保图片和标签文件一一对应
    paired_files = []
    for image_file in image_files:
        label_file = os.path.splitext(image_file)[0] + '.txt'
        if label_file in label_files:
            paired_files.append((image_file, label_file))

    # 随机打乱文件列表
    random.shuffle(paired_files)

    # 计算训练集和验证集的分割点
    split_index = int(len(paired_files) * train_ratio)
    train_files = paired_files[:split_index]
    val_files = paired_files[split_index:]

    # 创建训练集和验证集目录
    train_image_dir = os.path.join(image_dir, 'train')
    train_label_dir = os.path.join(label_dir, 'train')
    val_image_dir = os.path.join(image_dir, 'val')
    val_label_dir = os.path.join(label_dir, 'val')

    for dir_path in [train_image_dir, train_label_dir, val_image_dir, val_label_dir]:
        os.makedirs(dir_path, exist_ok=True)

    # 移动训练集文件
    for image_file, label_file in train_files:
        shutil.move(os.path.join(image_dir, image_file), os.path.join(train_image_dir, image_file))
        shutil.move(os.path.join(label_dir, label_file), os.path.join(train_label_dir, label_file))

    # 移动验证集文件
    for image_file, label_file in val_files:
        shutil.move(os.path.join(image_dir, image_file), os.path.join(val_image_dir, image_file))
        shutil.move(os.path.join(label_dir, label_file), os.path.join(val_label_dir, label_file))

    print(f"数据集划分完成！")
    print(f"训练集: {len(train_files)} 对图片和标签")
    print(f"验证集: {len(val_files)} 对图片和标签")

# 设置图片和标签目录
image_directory = "D:/pythonProject2/YOLOv8HFSA/ultralytics/datasets/images"  # 替换为你的图片目录
label_directory = "D:/pythonProject2/YOLOv8HFSA/ultralytics/datasets/labels"  # 替换为你的标签目录

# 划分数据集
split_dataset(image_directory, label_directory)